#include "Person.h"
#include <algorithm>
#include <numeric>
#include <iomanip>
#include <cstdlib>

Person::Person() : exam(0), finalGrade(0) {}

Person::Person(std::string n, std::string s)
    : name(n), surname(s), exam(0), finalGrade(0) {}

Person::Person(const Person& other)
    : name(other.name),
      surname(other.surname),
      homework(other.homework),
      exam(other.exam),
      finalGrade(other.finalGrade) {}

Person& Person::operator=(const Person& other) {
    if (this != &other) {
        name = other.name;
        surname = other.surname;
        homework = other.homework;
        exam = other.exam;
        finalGrade = other.finalGrade;
    }
    return *this;
}

Person::~Person() {}

void Person::addHomework(int mark) {
    homework.push_back(mark);
}

void Person::setExam(int mark) {
    exam = mark;
}

void Person::calculateFinal(bool useMedian) {
    double hwResult = 0;

    if (homework.empty()) return;

    if (useMedian) {
        std::vector<int> temp = homework;
        std::sort(temp.begin(), temp.end());
        int size = temp.size();
        if (size % 2 == 0)
            hwResult = (temp[size/2 - 1] + temp[size/2]) / 2.0;
        else
            hwResult = temp[size/2];
    } else {
        hwResult = std::accumulate(homework.begin(), homework.end(), 0.0)
                   / homework.size();
    }

    finalGrade = 0.4 * hwResult + 0.6 * exam;
}

std::string Person::getName() const { return name; }
std::string Person::getSurname() const { return surname; }
double Person::getFinal() const { return finalGrade; }

void Person::randomGenerate(int hwCount) {
    homework.clear();
    for (int i = 0; i < hwCount; i++)
        homework.push_back(rand() % 10 + 1);

    exam = rand() % 10 + 1;
}

std::ostream& operator<<(std::ostream& out, const Person& p) {
    out << std::left << std::setw(15) << p.name
        << std::setw(15) << p.surname
        << std::fixed << std::setprecision(2)
        << p.finalGrade;
    return out;
}