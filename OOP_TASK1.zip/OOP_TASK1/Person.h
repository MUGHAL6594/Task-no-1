#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <vector>
#include <string>

class Person {
private:
    std::string name;
    std::string surname;
    std::vector<int> homework;
    int exam;
    double finalGrade;

public:
    Person();
    Person(std::string n, std::string s);

    // Rule of Three
    Person(const Person& other);
    Person& operator=(const Person& other);
    ~Person();

    void addHomework(int mark);
    void setExam(int mark);

    void calculateFinal(bool useMedian);

    std::string getName() const;
    std::string getSurname() const;
    double getFinal() const;

    void randomGenerate(int hwCount);

    friend std::ostream& operator<<(std::ostream& out, const Person& p);
};

#endif