#include "Person.h"
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>

int main() {

    std::vector<Person> students;
    std::ifstream file("Students.txt");

    std::string name, surname;

    while (file >> name >> surname) {

        Person p(name, surname);

        int mark;
        std::vector<int> marks;

        // Read all numbers in line
        std::string line;
        std::getline(file, line);
        std::stringstream ss(line);

        while (ss >> mark)
            marks.push_back(mark);

        // Last value = exam
        int exam = marks.back();
        marks.pop_back();

        for (int m : marks)
            p.addHomework(m);

        p.setExam(exam);

        p.calculateFinal(false); // false = average

        students.push_back(p);
    }

    std::sort(students.begin(), students.end(),
        [](const Person& a, const Person& b) {
            return a.getSurname() < b.getSurname();
        });

    std::cout << std::left
              << std::setw(15) << "Name"
              << std::setw(15) << "Surname"
              << "Final (Avg.)\n";

    std::cout << "--------------------------------------\n";

    for (const auto& s : students)
        std::cout << s << std::endl;

    return 0;
}